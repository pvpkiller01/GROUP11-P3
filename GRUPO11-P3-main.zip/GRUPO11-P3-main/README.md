# GRUPO11-P3
Repo do grupo 11 para o proejto 3 da cadeira de Programação Avançada.


1. Abrir pelo terminal o caminho .../GRUPO11-P3
2. Executar no terminal o comando npm install (pode demorar alguns minutos)
3. O projeto foi feito pensando em utilizar a extensão live server do Visual Studio Code (https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer)

4. Após a abertura do servidor e fazer os passos citados acima, o programa irá correr normalmente
